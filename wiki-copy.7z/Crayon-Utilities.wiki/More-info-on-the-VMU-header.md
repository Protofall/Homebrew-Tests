This source was very useful when I needed to figure out the format. It has some stuff on crc calculation so you can modify savefiles on your own.

https://mc.pp.se/dc/vms/fileheader.html