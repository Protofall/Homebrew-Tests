Until I worked on my program I heard a lot of different things about Eyecatchers, but still didn't know much. Here is everything you need to know

* Eyecatchers are a part of a savefile similar to how the savefile icon is
* Eyecatchers are always 72 pixels wide and 56 pixels high and are in the ARGB4444 format
* Unlike the savefile icon, you can't have multiple frames of animation
* They come in 3 modes/types which controls how it represents the ARGB4444 image
	1. Type 1 is just plain old ARGB4444 and allows for as many colours as you want (`2 Bytes Per Pixel * 72 * 56 = 8064 Bytes = 15.75 Blocks`)
	2. Type 2 is PAL8BPP ARGB4444 and allows for a palette of 256 colours (`1 Byte Per Pixel * 72 * 56 = 8.875 Blocks`)
	3. Type 3 is PAL4BPP ARGB4444 and allows for a palette of 16 colours (`0.5 Bytes Per Pixel * 72 * 56 = 4 Blocks`)
* The savefile icon and Eyecatcher **DON'T** share the same palette, they both have their own (Except for EC type 1 which isn't paletted)
* You need to insert this mode/type value into KOS's `vmu_pkg_t`/`vmu_hdr_t` struct under the `eyecatch_type` parameter (If you have no Eyecatcher set this variable to zero)
* KOS also requires a pointer to the Eyecatcher binary when making a savefile. If using mode/type 2 or 3, the palette and body are one binary and the palette appears **first** followed by the body.
* Also note Each VMU has 200 Blocks (+44 if you hack it) so think about this when making your savefiles
* The Eyecatcher appears in the bottom right corner of your savefile details on the Dreamcast BIOS menu as seen in the picture below (It might take a few seconds to load in)

![](https://cdn.discordapp.com/attachments/537283154873024539/553047931083816962/D0-ps6YU8AACB9T.png)