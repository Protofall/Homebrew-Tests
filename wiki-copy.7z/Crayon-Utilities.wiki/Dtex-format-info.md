When making my DtexToRGBA8888 converter, there were some pieces of information that were hard for me to understand or just incorrect. Since then I've learnt how they actually work and have listed them below.

* Twiddling a texture changes the texel order such that its more efficient to draw the texture because memory jumps are generally shorter. Basically the texels are re-arranged into a "backwards-N" shape.

![](https://cdn.discordapp.com/attachments/537283154873024539/548722330285899781/unknown.png)

* Mipmap textures **MUST** be square
* Strided textures have a width that are multiples of 32, but the height is still a power of two (Note strided textures are less efficient to draw because they're in scanline order)
* YUV422 format represents pairs of texels. Each pair of texels is in the format of `y0 u y1 v` Where `y0 u` is kind of treated like 1 texel and `y1 v` is another. This is important to remember when twiddling
* Compressed textures can be rectangular despite what official SEGA documentation said.
* Compressed textures and **MUST** be twiddled. No stride or normal scan-line order allowed
* Compressed textures have two components. The code-book (Which is always 2KB) and the body (Which is `width * height / 2 / 2 / (16/bpp)` if that makes sense). The code-book contains 256 lots of 64-bit texel entries, this contains 4 pixels for 16bpp, 8 for 8bpp and 16 for 4bpp. Each entry is a n-by-m meta-texel (n and m depend on bpp) and compression is achieved when multiple body entries refer to the same code-book entry. Each body entry is an index for one of the entries of the code-book. I call the body entries "meta-texels"
* To understand how the twiddling and compression effects work together, think of it this way. Each code-book entry (meta-texels) is internally twiddled, so if we have 16bpp with 4 entries (0, 1, 2, 3) the real order is (0, 2, 1, 3). The body entries themselves are also twiddled
* You can Compress paletted textures, but how it works is a little confusing

![](https://cdn.discordapp.com/attachments/537283154873024539/557783406356725761/unknown.png)